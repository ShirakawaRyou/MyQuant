"""Cloud-only historical research; no accounts, orders or live trading APIs."""

import argparse
import json
from pathlib import Path
import sys

import pandas as pd

from .data import demo_bars, write_bars
from .engine import Config, run_backtest
from .reporting import save_result
from .research_data import fetch_snapshot, sha256, validate_actions
from .study import freeze, import_snapshot, read_protocol, run_stage, STAGES


def strategy_arguments(parser):
    parser.add_argument("--fast", type=int, default=20)
    parser.add_argument("--slow", type=int, default=60)
    parser.add_argument("--allocation", type=float, default=0.20)
    parser.add_argument("--cash", type=float, default=100_000)
    parser.add_argument("--commission-per-share", type=float, default=0.005)
    parser.add_argument("--minimum-commission", type=float, default=1.0)
    parser.add_argument("--slippage-bps", type=float, default=5.0)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="myquant", description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    demo = commands.add_parser("demo", help="Generate synthetic software-validation bars")
    demo.add_argument("--output", type=Path, default=Path("data/demo-v2.csv"))
    backtest = commands.add_parser("backtest", help="Single CSV experiment; requires explicit actions")
    backtest.add_argument("--csv", type=Path, required=True)
    backtest.add_argument("--out", type=Path, required=True)
    backtest.add_argument("--price-basis", choices=["as-traded"], help="Required declaration for CSV without metadata")
    strategy_arguments(backtest)
    for name in ("fetch", "import-csv", "freeze", "study"):
        subparser = commands.add_parser(name)
        subparser.add_argument("--config", type=Path, default=Path("research/protocol.json"))
        subparser.add_argument("--out", type=Path, required=True)
        if name in ("freeze", "study"):
            subparser.add_argument("--data", type=Path, required=True)
        if name == "import-csv":
            subparser.add_argument("--input-dir", type=Path, required=True)
            subparser.add_argument("--source-label", required=True)
            subparser.add_argument("--price-basis", choices=["as-traded"], required=True)
        if name == "study":
            subparser.add_argument("--freeze", type=Path, required=True)
            subparser.add_argument("--stage", choices=STAGES, default="development")
    args = parser.parse_args(argv)
    try:
        if args.command == "demo":
            metadata_path = args.output.with_suffix(args.output.suffix + ".json")
            if args.output.exists() or metadata_path.exists():
                raise ValueError("Output already exists; choose a new path")
            write_bars(demo_bars(), args.output)
            metadata_path.write_text(json.dumps({"source": "synthetic", "seed": 42,
                                                "price_basis": "as_traded", "actions": "explicit_no_events"}) + "\n")
            print(f"Saved 400 synthetic bars: {args.output}")
        elif args.command == "backtest":
            sidecar = args.csv.with_suffix(args.csv.suffix + ".json")
            metadata = json.loads(sidecar.read_text()) if sidecar.exists() else {"source": "user_csv"}
            if metadata.get("price_basis") != "as_traded" and args.price_basis != "as-traded":
                raise ValueError("Declare as-traded OHLC and explicit actions; adjusted prices cannot be assumed raw")
            bars = validate_actions(pd.read_csv(args.csv))
            result = run_backtest(bars, Config(
                fast=args.fast, slow=args.slow, allocation=args.allocation, initial_cash=args.cash,
                commission_per_share=args.commission_per_share, minimum_commission=args.minimum_commission,
                slippage_bps=args.slippage_bps))
            result.summary.update({"input_csv": str(args.csv.resolve()), "input_sha256": sha256(args.csv),
                                   "data_source": metadata, "evaluation": "single CSV exploratory run; not held-out research"})
            save_result(result, args.out)
            print(json.dumps(result.summary, indent=2, allow_nan=False))
        elif args.command == "fetch":
            protocol = read_protocol(args.config)
            print(json.dumps(fetch_snapshot(protocol["universe"], protocol["history_start"],
                                             protocol["history_end_exclusive"], args.out), indent=2))
        elif args.command == "import-csv":
            print(json.dumps(import_snapshot(args.config, args.input_dir, args.out, args.source_label), indent=2))
        elif args.command == "freeze":
            record = freeze(args.config, args.data, args.out)
            print(json.dumps({key: value for key, value in record.items() if key != "protocol"}, indent=2))
        elif args.command == "study":
            if args.out.exists() and any(args.out.iterdir()):
                raise ValueError("Report path already contains files")
            result = run_stage(args.config, args.data, args.freeze, args.stage)
            save_result(result, args.out)
            print(json.dumps({key: result.summary[key] for key in [
                "stage", "start", "end", "bars", "net_return", "annualized_return", "max_drawdown",
                "fills", "commissions", "slippage_cost", "average_exposure", "benchmark", "rejected_orders"]}, indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError, RuntimeError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
