"""Standalone, reproducible research reports without a web server."""

import json
import os
from pathlib import Path
import tempfile


def save_result(result, output: Path) -> None:
    if output.exists() and any(output.iterdir()):
        raise ValueError("Report directory is not empty; choose a new --out path")
    os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "myquant-matplotlib"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output.mkdir(parents=True, exist_ok=True)
    result.equity.to_csv(output / "equity.csv", index_label="date")
    result.trades.to_csv(output / "trades.csv", index=False)
    result.benchmark_trades.to_csv(output / "benchmark_trades.csv", index=False)
    result.positions.to_csv(output / "positions.csv", index_label="date")
    result.actions.to_csv(output / "corporate_actions.csv", index=False)
    result.rejected.to_csv(output / "rejections.csv", index=False)
    (output / "summary.json").write_text(json.dumps(result.summary, indent=2, allow_nan=False) + "\n")
    figure, axes = plt.subplots(2, 1, figsize=(11, 7), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
    for column, label in [("equity", "Strategy net"), ("benchmark_net", "Buy-and-hold net")]:
        axes[0].plot(result.equity.index, result.equity[column], label=label, linewidth=1.4)
    for column, label in [("strategy_drawdown", "Strategy"), ("benchmark_drawdown", "Buy-and-hold")]:
        axes[1].plot(result.equity.index, result.equity[column] * 100, label=label)
    axes[0].set(title=f"{result.summary.get('stage', 'Backtest')} | identical capital and transaction costs", ylabel="USD")
    axes[1].set(ylabel="Drawdown %")
    for axis in axes:
        axis.grid(alpha=0.25)
        axis.legend(loc="best")
    figure.autofmt_xdate()
    figure.tight_layout()
    figure.savefig(output / "equity.png", dpi=160)
    plt.close(figure)
    summary, baseline = result.summary, result.summary["benchmark"]
    lines = [f"# {summary.get('stage', 'backtest')}", "", f"{summary['start']} → {summary['end']}", "",
             "| Metric | Strategy net | Buy-and-hold net |", "|---|---:|---:|"]
    for label, key in [("Total return", "net_return"), ("Annualized return", "annualized_return"),
                       ("Maximum drawdown", "max_drawdown"), ("Average exposure", "average_exposure")]:
        lines.append(f"| {label} | {summary[key]:.2%} | {baseline[key]:.2%} |")
    lines += [f"| Commissions (USD) | {summary['commissions']:.2f} | {baseline['commissions']:.2f} |",
              f"| Fills | {summary['fills']} | {baseline['fills']} |", "", "![Equity and drawdown](equity.png)", "",
              "Corporate actions are explicit; cash distributions are not reinvested. Ending positions are marked to market, not liquidated.",
              "Historical results do not establish future profitability. The fixed survivor universe has selection bias.", ""]
    (output / "report.md").write_text("\n".join(lines))
